import React from "react";
import "./styles/UserProfile.css";
export default function UserProfile() {
  return (
    <div>
      <div className="hero"></div>
    </div>
  );
}
