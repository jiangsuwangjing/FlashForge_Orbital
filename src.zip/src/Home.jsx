import React from "react";
import Header from "./Header";

export default function Home() {
  return (
    <div>
      <Header />
      <h1 style={{ margin: "20px" }}>Home</h1>
    </div>
  );
}
