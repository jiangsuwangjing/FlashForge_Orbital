import { useState, useEffect, useCallback } from "react";
import { doc, getDoc, getDocs, collection, setDoc, updateDoc, arrayUnion, query, where } from 'firebase/firestore';
import { db, auth } from "../config/firebase";
import useAuthStore from "../store/authStore";
import useGetCardList from "../hooks/useGetCardList";
import { Await } from "react-router-dom";
import UnshareDeck from "./UnshareDeck";

const getUserProfileByEmail = async (email) => {
  try {
    const q = query(collection(db, "users"), where("email", "==", email));
    const querySnapshot = await getDocs(q);

    if (querySnapshot.empty) {
      console.log("User does not exist");
      return null;
    }

    let userDoc;
    querySnapshot.forEach((doc) => {
      userDoc = doc.data();
    });

    return userDoc;
  } catch (error) {
    console.error('Error fetching user profile:', error);
    throw error;
  }
};

const ShareDeck = ({ deckName }) => {
  const srcUser = useAuthStore((state) => state.user);
  const srcDeckRef = doc(db, "users", srcUser.uid, "library", deckName);
  const { cardList, sharedTo }= useGetCardList(deckName, srcDeckRef);

  const [destUserEmail, setDestUserEmail] = useState('');
  const [destUserList, setDestUserList] = useState([]);
  
  useEffect(() => {
    setDestUserList(sharedTo);
  }, [sharedTo]);
  console.log(destUserList);
  
  const onShareDeck = async () => {
    try {
      const destUser = await getUserProfileByEmail(destUserEmail);
      const srcDeckDoc = await getDoc(srcDeckRef);
      const srcDeckData = srcDeckDoc.data();

      if (!destUser) {
        alert('Destination user not found.');
        return;
      }
    
      // Add the destination user to the sharedTo array in the source deck
      await updateDoc(srcDeckRef, {
        sharedTo: arrayUnion(destUser.uid)
      });

      setDestUserList((prevList) => [...prevList, destUser.uid]);
      // Copy the deck to the destination user's library
      const destDeckRef = doc(db, "users", destUser.uid, "shared", deckName);
      await setDoc(destDeckRef, srcDeckData);

      const destCardsRef = collection(destDeckRef, "cards");
      
      cardList.forEach(async (card) => {
        const newCardRef = doc(destCardsRef, card.id);
        await setDoc(newCardRef, {...card, mastery: 0});
      })
  
      alert('Deck shared successfully.');
    } catch (error) {
      console.error('Error sharing deck:', error);
      alert('An error occurred while sharing the deck.');
    }
  };

  return (
    <div>
      <input
        type="email"
        placeholder="Enter target user email"
        value={destUserEmail}
        onChange={(e) => setDestUserEmail(e.target.value)}
      />
      <button onClick={onShareDeck}>Share Deck</button>
      <ul>
        {destUserList.map((uid) => (
          <UnshareDeck 
            key={uid} 
            deckName={deckName} 
            deckRef={srcDeckRef} 
            destUid={uid} 
          />
        ))}
      </ul>
    </div>
  );
};

export default ShareDeck;

